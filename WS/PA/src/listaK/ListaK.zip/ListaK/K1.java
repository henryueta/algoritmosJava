package listaK;

import java.util.Scanner;

public class K1 {

	public static void main(String[] args) {
    int num = 0,num2 = 0;
    
	do {
	System.out.println(num++);
	}while(num<100);
		
	do {
	System.out.println(num--);
	}while(num>num2);
		

	
	}

}
